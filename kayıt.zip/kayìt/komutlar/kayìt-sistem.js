const Discord = require('discord.js');
const data = require('quick.db');

exports.run = async (client, message, args) => {
  Array.prototype.random = function() {
    return this[Math.floor(Math.random() * this.length)];
  }

let ayarlar = require("../ayarlar.json")
let prefix = await require("quick.db").fetch(`prefix.${message.guild.id}`) || ayarlar.prefix
let images = ['https://media.giphy.com/media/mBkM18U5OMSkTcDmeu/giphy.gif', 'https://media.giphy.com/media/RGRzukK0YNlQbZEUVP/giphy.gif'];
message.channel.send(new Discord.MessageEmbed().setColor('#000001').setDescription(`**Lykia Ana Menüsüne Hoş Geldin Dostum :innocent:
${client.user} Kullanırken \`@Lykia\` rolünü en yukarıda tutunuz.**
**

  Selam, Kayıt Yetkili Rolünü Ayarlamak İçin Bir Seçenek Belirtmen Lazım Aşşağıda Örnekler Var:
  
  \`${prefix}k-y-rol @rol\`
  \`${prefix}k-y-rol kapat\`
  Bu Seçenekleri Kullanabilirsiniz

Erkek ve Kadın Rolünü Ayarlamak İçin Aşşağıda Verdiğimiz Seçenekleri Kullan!:
  
>  \`${prefix}k-erkek-rol @rol\`
>  \`${prefix}k-erkek-rol kapat\`
>  \`${prefix}k-kadın-rol @rol\`
>  \`${prefix}k-kadın-rol kapat\`
  
Selam, Kayıt İsim Düzenini Ayarlayabilmek İçin Seçenek Belirtmen Gerek Örnekler Aşşağıda:
      
      \`${prefix}k-isim-düzen {isim} / {yas}\`
      \`${prefix}k-isim-düzen 主 {yas} | {isim}\`
      \`${prefix}k-isim-düzen kapat\`
      **Ve Sizin Belirttiğiniz Başka İsimler**
      
      Değişkenler:
      
      {isim} {yas}
      **(Kayıt ederken Kayıt Sorumlusu İsim ve yaş Yazmaz ise değiştirilmez)**

Kayıt Kanalını Ayarlamak İçin Aşşağıda Verdiğimiz Seçenekleri Kullanabilirsiniz:
    
> \`${prefix}k-log #kanal\`,
> \`${prefix}k-log kapat\`,
      Bu Seçenekleri Kullanabilirsiniz. 

  Bir Seçenek Belirtmen Gerekmekte Örnekler Hemen Aşşağıda:
  
  \`${prefix}k-oto-rol @rol\`
  \`${prefix}k-oto-rol kapat\`
  Bu Seçenekleri Kullanabilirsiniz.	  

💐 Lykia
**`).setThumbnail(message.author.avatarURL() ? message.author.avatarURL({dynamic: true}) : 'https://cdn.glitch.com/8e70d198-9ddc-40aa-b0c6-ccb4573f14a4%2F6499d2f1c46b106eed1e25892568aa55.png').setImage(images.random()))

};
exports.conf = {
  enabled: true,
  guildOnly: true,
  aliases: [],
  permLevel: 0
}

exports.help = {
  name: 'kayıt-sistem'
};