const Discord = require('discord.js');
const data = require('quick.db');

exports.run = async (client, message, args) => {
 let ayarlar = require("../ayarlar.json")
let prefix = await require("quick.db").fetch(`prefix.${message.guild.id}`) || ayarlar.prefix

message.channel.send(new Discord.MessageEmbed().setTitle('Lykia Ban Sistem').setDescription(`
\`${prefix}ban-log [@kanalEtiket]\`
**Belirtilen kanala yasaklanma bilgisini gönderir**

\`${prefix}ban-yetki-role [@rolEtiket]\`
**Belirtilen rolü olan kişi sadece yasaklama yapabilir**
\`\`\`Komutları kapatma kısmı aşağıda\`\`\`

\`${prefix}ban-yetki-role-kapat\`
**Yasaklama yetkili rolünü kapatır**

\`${prefix}ban-kanal-kapat\`
**Ban log kanalını sıfırlar**

**Ban komut nasıl kullanırım?**

\`${prefix}ban @üyeetiketi açıklama\`

🔨 \`${prefix}unban [Kullanıcı ID]\`
**Sunucunuzdan yasaklı kullanıcının yasağını kaldırır**`)
.setThumbnail(message.author.avatarURL() ? message.author.avatarURL({dynamic: true}) : 'https://cdn.glitch.com/8e70d198-9ddc-40aa-b0c6-ccb4573f14a4%2F6499d2f1c46b106eed1e25892568aa55.png'));

};
exports.conf = {
  enabled: true,
  guildOnly: true,
  aliases: [],
  permLevel: 0
}

exports.help = {
  name: 'ban-sistem'
};